import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const appUrl = new URL('../public/app.js', import.meta.url);

test('solve detail hides stage timing when the solve has no bluetooth data', async () => {
  const appSource = await readFile(appUrl, 'utf8');

  assert.match(
    appSource,
    /renderSolveAnalysis\(solve, solution\.displayedStages, \{ hasBluetoothData: solution\.hasData \}\);/,
  );
  assert.match(
    appSource,
    /function renderSolveAnalysis\(solve, displayedStages, options = \{\}\) \{\s*elements\.solveAnalysisPanel\.hidden = !options\.hasBluetoothData;\s*if \(!options\.hasBluetoothData\) \{[\s\S]*?return;/,
  );
});
