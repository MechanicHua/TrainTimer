import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const stylesUrl = new URL('../public/styles.css', import.meta.url);

test('header controls stay centered and independent from dynamic timer status', async () => {
  const stylesSource = await readFile(stylesUrl, 'utf8');

  assert.match(
    stylesSource,
    /\.topbar\s*\{[^}]*display:\s*grid;[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)\s*minmax\(0,\s*max-content\)\s*max-content\s*max-content\s*minmax\(0,\s*1fr\)/s,
  );
  assert.match(
    stylesSource,
    /\.brand-box\s*\{[^}]*width:\s*100%;[^}]*min-width:\s*0;/s,
  );
  assert.match(
    stylesSource,
    /\.brand-box p\s*\{[^}]*flex:\s*1 1 auto;[^}]*min-width:\s*0;[^}]*max-width:\s*none;[^}]*text-overflow:\s*ellipsis;/s,
  );
  assert.match(
    stylesSource,
    /\.session-box\s*\{[^}]*justify-self:\s*start;/s,
  );
  assert.match(
    stylesSource,
    /@media \(max-width:\s*1120px\)[\s\S]*?\.app-shell\s*\{[^}]*grid-template-rows:\s*auto[^;}]*;[^}]*\}[\s\S]*?\.topbar\s*\{[^}]*display:\s*flex;[^}]*flex-wrap:\s*wrap;[^}]*justify-content:\s*center;[^}]*overflow:\s*visible;/s,
  );
  assert.match(
    stylesSource,
    /@media \(max-width:\s*1120px\)[\s\S]*?\.brand-box,\s*\.bluetooth-box\s*\{[^}]*flex:\s*0 0 100%;/s,
  );
});
