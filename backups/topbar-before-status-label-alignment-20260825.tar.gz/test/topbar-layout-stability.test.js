import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const stylesUrl = new URL('../public/styles.css', import.meta.url);
const indexUrl = new URL('../public/index.html', import.meta.url);
const appUrl = new URL('../public/app.js', import.meta.url);

test('header controls use the grouped reference layout without changing their ids', async () => {
  const [stylesSource, indexSource] = await Promise.all([
    readFile(stylesUrl, 'utf8'),
    readFile(indexUrl, 'utf8'),
  ]);

  assert.match(
    stylesSource,
    /\.app-shell\s*\{[^}]*grid-template-rows:\s*76px\s+minmax\(116px,\s*auto\)/s,
  );
  assert.match(
    stylesSource,
    /\.topbar\s*\{[^}]*display:\s*grid;[^}]*grid-template-columns:\s*minmax\(124px,\s*1fr\)[^}]*border-radius:\s*16px;[^}]*backdrop-filter:\s*blur\(18px\)/s,
  );
  assert.match(
    stylesSource,
    /\.session-select-control\s*\{[^}]*width:\s*164px;/s,
  );
  assert.match(
    stylesSource,
    /\.session-box\s*\{(?=[^}]*align-items:\s*flex-start;)[^}]*\}/s,
  );
  assert.match(
    stylesSource,
    /\.session-box \.topbar-icon-action\s*\{(?=[^}]*grid-template-rows:\s*38px auto;)(?=[^}]*min-height:\s*53px;)[^}]*\}/s,
  );
  assert.match(
    stylesSource,
    /\.topbar-icon-frame\s*\{(?=[^}]*width:\s*38px;)(?=[^}]*height:\s*38px;)[^}]*box-shadow:\s*var\(--topbar-edge-glow\);/s,
  );
  assert.match(
    stylesSource,
    /\.topbar :is\([\s\S]*?\.bluetooth-status[\s\S]*?\)\s*\{[^}]*box-shadow:\s*var\(--topbar-edge-glow\);/s,
  );
  assert.match(
    stylesSource,
    /\.bluetooth-box\s*\{[^}]*border-left:\s*1px solid/s,
  );
  assert.match(
    stylesSource,
    /@media \(max-width:\s*620px\)[\s\S]*?\.session-box\s*\{[^}]*flex-wrap:\s*wrap;/s,
  );
  assert.match(
    stylesSource,
    /@media \(max-width:\s*980px\) and \(max-height:\s*620px\)[\s\S]*?\.session-box select[\s\S]*?min-height:\s*44px;/s,
  );

  for (const id of [
    'sessionSelect',
    'newSessionButton',
    'duplicateSessionButton',
    'mergeSessionButton',
    'renameSessionButton',
    'timerSettingsButton',
    'deleteSessionButton',
    'inspectionToggle',
    'bluetoothButton',
    'bluetoothAnyButton',
    'bluetoothReconnectButton',
    'bluetoothDisconnectButton',
    'bluetoothLogButton',
    'bluetoothStatus',
  ]) {
    assert.match(indexSource, new RegExp(`id=["']${id}["']`), `${id} should remain wired`);
  }

  assert.match(indexSource, /class="session-grid-icon"/);
  assert.match(indexSource, /id="newSessionButton"[^>]*class="topbar-icon-action"[\s\S]*?class="topbar-action-label">新会话</);
  assert.match(indexSource, /id="bluetoothButton"[\s\S]*?class="topbar-control-label">连接蓝牙魔方</);
  assert.match(indexSource, /class="inspection-check"/);
});

test('dynamic bluetooth rendering preserves the grouped button and connection indicator', async () => {
  const appSource = await readFile(appUrl, 'utf8');

  assert.match(appSource, /setTopbarControlLabel\(elements\.bluetoothButton,\s*'连接蓝牙魔方'\)/);
  assert.match(appSource, /closest\('\.bluetooth-status'\)\?\.classList\.toggle\('connected',\s*connected\)/);
  assert.match(appSource, /function setTopbarControlLabel\(button,\s*label\)[\s\S]*?querySelector\('\.topbar-control-label'\)/);
});
